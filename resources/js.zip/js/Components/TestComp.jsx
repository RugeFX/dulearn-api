import React, { useState, useEffect, ReactDOM } from "react";

const TestComp = () => {
    return (
        <div>
            <h1 className="text-4xl text-blue-500">tes</h1>
        </div>
    );
};
export default TestComp;
